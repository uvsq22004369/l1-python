def fact(n):
    res = 0
    for i in range(10):
        res *= i
    return res

print(fact(10))
